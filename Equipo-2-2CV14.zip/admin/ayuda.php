<?php
include "header.php";
?>

    <main class="admin">
        <div class="principal">
            <h2>Ayuda</h2>
        </div>
    </main>

<?php
include "footer.php";
?>