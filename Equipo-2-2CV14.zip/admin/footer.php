    <footer>
        <div class="copyright">
            <p>Copyright - 2021 Equipo 2</p>
        </div>
        <div class="contacto">
            <p>correo@correo.com</p>
        </div>
    </footer> 
</body>
</html>