<?php
include "header.php";
?>

    <main class="alumno">
        <div class="principal">
            <h2>¡Bienvenido Alumno!</h2>
        </div>
    </main>

<?php
include "footer.php";
?>
