<?php
include "header.php";
?>

    <main class="alumno">
        <div class="principal">
            <h2>Soporte</h2>
        </div>
    </main>

<?php
include "footer.php";
?>
