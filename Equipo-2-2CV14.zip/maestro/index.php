<?php
include "header.php";
?>

    <main class="maestro">
        <div class="principal">
            <h2>¡Bienvenido Maestro!</h2>
        </div>
    </main>

<?php
include "footer.php";
?>