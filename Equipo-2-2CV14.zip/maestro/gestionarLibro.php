<?php
include "header.php";
?>

    <main class="maestro libro">
        <div class="principal">
            <h2>Gestionar Libro</h2>
            <iframe src="https://libros.conaliteg.gob.mx/2021/P1MAA.htm?#page/10" frameborder="0"></iframe>

        </div>
    </main>

<?php
include "footer.php";
?>