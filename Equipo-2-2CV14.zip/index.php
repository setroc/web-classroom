<?php
include "header.php";
?>
    <main class="noLoggeado">
        <div class="principal">
            <h2>¡Bienvenido al proyecto de Técnologias para la WEB!</h2>
            <p>
                Hola, nosotros somos una plataforma online la cual busca acercar al profesor y alumno(s) facilitandoles una aula virtual donde los profesores podran cargar material de ayuda a los alumnos y estos lo podran consultarla en cualquier momento.
            </p>
            <img src="https://images.squarespace-cdn.com/content/v1/53aadf1de4b0a0a817640cca/1561148351726-FXU6BX7JQQBHT6B9VC7U/sal%C3%B3n+lleno?format=500w" alt="aula">
        </div>
        <?php
        include "login.php";
        ?>
    </main>
<?php
include "footer.php";
?>