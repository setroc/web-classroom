<?php
include "header.php";
?>

    <main class="noLoggeado">
        <div class="principal">
            <h2>Preguntas frecuentes</h2>
            <div class="pregunta">
                <p>¿Cómo me registro?</p>
                <p class="respuesta">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Non nisi eos saepe. Quam totam consequatur deserunt repudiandae quaerat eius corrupti autem. Ratione id possimus hic, eius maiores illum magnam qui?
                </p>
            </div>
            <div class="pregunta">
                <p>¿Cómo me registro?</p>
                <p class="respuesta">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Non nisi eos saepe. Quam totam consequatur deserunt repudiandae quaerat eius corrupti autem. Ratione id possimus hic, eius maiores illum magnam qui?
                </p>
            </div>
            <div class="pregunta">
                <p>¿Cómo me registro?</p>
                <p class="respuesta">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Non nisi eos saepe. Quam totam consequatur deserunt repudiandae quaerat eius corrupti autem. Ratione id possimus hic, eius maiores illum magnam qui?
                </p>
            </div>
            <div class="pregunta">
                <p>¿Cómo me registro?</p>
                <p class="respuesta">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Non nisi eos saepe. Quam totam consequatur deserunt repudiandae quaerat eius corrupti autem. Ratione id possimus hic, eius maiores illum magnam qui?
                </p>
            </div>
        </div>
        <?php
        include "login.php";
        ?>
    </main>
<?php
include "footer.php";
?>