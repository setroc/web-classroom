<?php
include "header.php";
?>

    <main class="noLoggeado">
        <div class="principal">
            <h2>Ayuda</h2>
            
            
            <p>
                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Fugit, neque aperiam? Facere voluptas eius, omnis doloribus modi, optio perferendis rerum laudantium eveniet veniam tempore voluptatem amet fuga ipsam aut praesentium?
            </p>
            <img src="https://www.webconsultas.com/sites/default/files/pedir_ayuda.jpg" alt="imagen">
        </div>
        <?php
        include "login.php";
        ?>
    </main>

<?php
include "footer.php";
?>