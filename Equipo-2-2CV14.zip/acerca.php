<?php
include "header.php";
?>
    <main class="noLoggeado">
        <div class="principal">
            <h2>Acerca de nosotros</h2>
            <p> Realizado por:</p>
            <ul>
                <li>Isaac Godínez Cortés</li>
            </ul>
        </div>
        <?php
        include "login.php";
        ?>
    </main>

<?php
include "footer.php";
?>